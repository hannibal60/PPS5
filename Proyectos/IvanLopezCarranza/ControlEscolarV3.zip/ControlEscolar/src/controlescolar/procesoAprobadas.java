/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlescolar;

import static controlescolar.procesoCalificaciones.resultadoG1;
import static controlescolar.procesoCalificaciones.resultadoG2;
import static controlescolar.procesoCalificaciones.resultadoG3;
import static controlescolar.procesoCalificaciones.resultadoG4;
import static controlescolar.procesoCalificaciones.resultadoG5;
import static controlescolar.procesoCalificaciones.resultadoG6;
import static controlescolar.procesoCalificaciones.resultadoG7;
import java.awt.Component;
import javax.swing.JOptionPane;

/**
 *
 * @author Ivan
 */
public class procesoAprobadas extends Thread
{   
    
    public static int contadorA;
    public static int contadorR;
    private Component rootPane;
    
    @Override
    public void run()
    {
        
        if (    resultadoG1 >= 8) 
        {
            contadorA++;
        }
        else
        {
            contadorR++;
        }
        
        if (    resultadoG2 >= 8) 
        {
            contadorA++;
        }
        else
        {
            contadorR++;
        }
        
        if (    resultadoG3 >= 8) 
        {
            contadorA++;
        }
        else
        {
            contadorR++;
        }
        
        if (    resultadoG4 >= 8) 
        {
            contadorA++;
        }
        else
        {
            contadorR++;
        }
        
        if (    resultadoG5 >= 8) 
        {
            contadorA++;
        }
        else
        {
            contadorR++;
        }
        
        if (    resultadoG6 >= 8) 
        {
            contadorA++;
        }
        else
        {
            contadorR++;
        }
        
        if (    resultadoG7 >= 8) 
        {
            contadorA++;
        }
        else
        {
            contadorR++;
        }
        
        System.out.println("APROBADAS:"+contadorA);
        System.out.println("REPROBADAS"+contadorR);
        
        JOptionPane.showMessageDialog(rootPane, "            Resumen de calificaciones\n"+
                                                    "Usted cuenta con " + contadorA + " materias aprobadas\n"+
                                                    "Usted cuenta con " + contadorR + " materiasen ordinario");
        /*JOptionPane.showMessageDialog(parentComponent, this);*/
        
    }
    
}
