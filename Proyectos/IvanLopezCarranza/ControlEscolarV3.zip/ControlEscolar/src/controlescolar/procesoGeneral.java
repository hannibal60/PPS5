/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlescolar;

import static controlescolar.VtnCalificaciones.califG1;
import static controlescolar.VtnCalificaciones.califG2;
import static controlescolar.VtnCalificaciones.califG3;
import static controlescolar.VtnCalificaciones.califG4;
import static controlescolar.VtnCalificaciones.califG5;
import static controlescolar.VtnCalificaciones.califG6;
import static controlescolar.VtnCalificaciones.califG7;
import static controlescolar.VtnCalificaciones.campoGeneral1;
import static controlescolar.VtnCalificaciones.campoGeneral2;
import static controlescolar.VtnCalificaciones.campoGeneral3;
import static controlescolar.VtnCalificaciones.campoGeneral4;
import static controlescolar.VtnCalificaciones.campoGeneral5;
import static controlescolar.VtnCalificaciones.campoGeneral6;
import static controlescolar.VtnCalificaciones.campoGeneral7;
import static controlescolar.VtnCalificaciones.campoPromGeneral;

/**
 *
 * @author Ivan
 */
public class procesoGeneral extends Thread
{   
    public static Double resultadoGeneral;
    
    
    @Override
    public void run()
    {
        califG1=campoGeneral1.getText();
        califG2=campoGeneral2.getText();
        califG3=campoGeneral3.getText();
        califG4=campoGeneral4.getText();
        califG5=campoGeneral5.getText();
        califG6=campoGeneral6.getText();
        califG7=campoGeneral7.getText();
        
        System.out.println("CALIFICACION GENERAL 1: "+ califG1);
        
        Double resultadoSuma;
        
        resultadoSuma=  Double.parseDouble(califG1) + Double.parseDouble(califG2)+ Double.parseDouble(califG3)+
                        Double.parseDouble(califG4) + Double.parseDouble(califG5) + Double.parseDouble(califG6) +
                        Double.parseDouble(califG7);
        

        Double resultadodecimal; 
        resultadodecimal = resultadoSuma / 7;
        
        resultadoGeneral = redondearDecimales(resultadodecimal,2);

        campoPromGeneral.setText(resultadoGeneral.toString());
        
    }
    
    public static double redondearDecimales(double valorInicial, int numeroDecimales) {
        double parteEntera, resultado;
        resultado = valorInicial;
        parteEntera = Math.floor(resultado);
        resultado=(resultado-parteEntera)*Math.pow(10, numeroDecimales);
        resultado=Math.round(resultado);
        resultado=(resultado/Math.pow(10, numeroDecimales))+parteEntera;
        return resultado;
    }
}
