/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controlescolar;

import static controlescolar.VtnCalificaciones.califP1;
import static controlescolar.VtnCalificaciones.califP2;
import static controlescolar.VtnCalificaciones.califP3;
import static controlescolar.VtnCalificaciones.califP4;
import static controlescolar.VtnCalificaciones.califP5;
import static controlescolar.VtnCalificaciones.califP6;
import static controlescolar.VtnCalificaciones.califP7;
import static controlescolar.VtnCalificaciones.califS1;
import static controlescolar.VtnCalificaciones.califS2;
import static controlescolar.VtnCalificaciones.califS3;
import static controlescolar.VtnCalificaciones.califS4;
import static controlescolar.VtnCalificaciones.califS5;
import static controlescolar.VtnCalificaciones.califS6;
import static controlescolar.VtnCalificaciones.califS7;
import static controlescolar.VtnCalificaciones.campoGeneral1;
import static controlescolar.VtnCalificaciones.campoGeneral2;
import static controlescolar.VtnCalificaciones.campoGeneral3;
import static controlescolar.VtnCalificaciones.campoGeneral4;
import static controlescolar.VtnCalificaciones.campoGeneral5;
import static controlescolar.VtnCalificaciones.campoGeneral6;
import static controlescolar.VtnCalificaciones.campoGeneral7;

/**
 *
 * @author Ivan
 */
public class procesoCalificaciones extends Thread
{
    public static Double resultadoG1;
    public static Double resultadoG2;
    public static Double resultadoG3;
    public static Double resultadoG4;
    public static Double resultadoG5;
    public static Double resultadoG6;
    public static Double resultadoG7;
    public static Double resultadoG8;
    
    
    @Override
    public void run()
    {   
        //variables para almacenar la suma
        Double resultado1;
        Double resultado2;
        Double resultado3;
        Double resultado4;
        Double resultado5;
        Double resultado6;
        Double resultado7;
        
        //CALIFICACION GENERAL 1
        resultado1=Double.parseDouble(califP1) + Double.parseDouble(califS1);
        resultadoG1 = resultado1/2; 
        
        //CALIFICACION GENERAL 2
        resultado2=Double.parseDouble(califP2) + Double.parseDouble(califS2);
        resultadoG2 = resultado2/2; 
        
        //CALIFICACION GENERAL 3
        resultado3=Double.parseDouble(califP3) + Double.parseDouble(califS3);
        resultadoG3 = resultado3/2; 
        
        //CALIFICACION GENERAL 4
        resultado4=Double.parseDouble(califP4) + Double.parseDouble(califS4);
        resultadoG4 = resultado4/2; 
        
        //CALIFICACION GENERAL 5
        resultado5=Double.parseDouble(califP5) + Double.parseDouble(califS5);
        resultadoG5 = resultado5/2; 
        
        //CALIFICACION GENERAL 6
        resultado6=Double.parseDouble(califP6) + Double.parseDouble(califS6);
        resultadoG6 = resultado6/2; 
        
        //CALIFICACION GENERAL 7
        resultado7=Double.parseDouble(califP7) + Double.parseDouble(califS7);
        resultadoG7 = resultado7/2; 
        
        campoGeneral1.setText(resultadoG1.toString());
        campoGeneral2.setText(resultadoG2.toString());
        campoGeneral3.setText(resultadoG3.toString());
        campoGeneral4.setText(resultadoG4.toString());
        campoGeneral5.setText(resultadoG5.toString());
        campoGeneral6.setText(resultadoG6.toString());
        campoGeneral7.setText(resultadoG7.toString());
        
        
    }
}
