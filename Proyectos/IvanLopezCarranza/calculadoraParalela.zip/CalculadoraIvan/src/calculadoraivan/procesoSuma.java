/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoraivan;

import static calculadoraivan.calculadoraParalela.n1;
import static calculadoraivan.calculadoraParalela.n2;
import static calculadoraivan.calculadoraParalela.resultadoSuma;
import static calculadoraivan.procesoResta.redondearDecimales;

/**
 *
 * @author Ivan
 */
public class procesoSuma extends Thread
{
    @Override
    public void run()
    {
        resultadoSuma=n1+n2;
        
        
        //System.out.println("El resultado de la suma es "+resultadoSuma);
        System.out.println(n1+" + "+n2+" = "+redondearDecimales(resultadoSuma,3));
        
    }
}
