/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoraivan;

import static calculadoraivan.calculadoraParalela.n1;
import static calculadoraivan.calculadoraParalela.n2;
import static calculadoraivan.calculadoraParalela.resultadoResta;
import java.text.DecimalFormat;

/**
 *
 * @author Ivan
 */
public class procesoResta extends Thread
{
    public void run()
    {   
        resultadoResta=n1-n2;
        
        //System.out.println("El resultado de la resta es "+resultadoResta);
        System.out.println(n1+" - "+n2+" = "+redondearDecimales(resultadoResta,3));
        
    }
    
    
    public static double redondearDecimales(double valorInicial, int numeroDecimales) {
        double parteEntera, resultado;
        resultado = valorInicial;
        parteEntera = Math.floor(resultado);
        resultado=(resultado-parteEntera)*Math.pow(10, numeroDecimales);
        resultado=Math.round(resultado);
        resultado=(resultado/Math.pow(10, numeroDecimales))+parteEntera;
        return resultado;
    }
}

