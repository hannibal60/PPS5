/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoraivan;

import java.util.Scanner;


public class calculadoraParalela 
{
    public static double n1;
    public static double n2;
    
    public static double resultado;
    
    public static double resultadoSuma;
    public static double resultadoResta;
    
    public static double resultadoDivision;
    public static double resultadoMulti;
    
    
    public static void main(String[] args) 
    {
        
        Scanner reader = new Scanner(System.in);
        
        procesoSuma hiloSuma = new procesoSuma();
        procesoResta hiloResta = new procesoResta();
        procesoMulti hiloMulti = new procesoMulti();
        procesoDivision hiloDiv = new procesoDivision();
        
        
        int opc;
        int opc2;
        
        
        System.out.println("LISTA DE OPCIONES");
        System.out.println("1. Suma");
        System.out.println("2. Resta");
        System.out.println("3. Division");
        System.out.println("4. Multiplicacion");
        System.out.println("5. Paralela");
        System.out.println("6. Salir");
        
        System.out.println("Escriba el numero de la operacion que desea realizar:");
        
        opc = reader.nextInt();

        while(opc!=6)
        {
            switch(opc)
            {
                case 1:
                {
                    System.out.println("Numero 1:");
                    n1 = reader.nextDouble();
                    System.out.println("Numero 2:");
                    n2 = reader.nextDouble();
                    resultado=n1+n2;
                    System.out.println("El resultado de la suma es "+resultado);
                    
                    break;
                }
                case 2:
                {
                    System.out.println("Numero 1:");
                    n1 = reader.nextDouble();
                    System.out.println("Numero 2:");
                    n2 = reader.nextDouble();
                    resultado=n1-n2;
                    System.out.println("El resultado de la resta es "+resultado);
                    break;
                }
                case 3:
                {
                    System.out.println("Numero 1:");
                    n1 = reader.nextDouble();
                    System.out.println("Numero 2:");
                    n2 = reader.nextDouble();
                    resultado=n1*n2;
                    System.out.println("El resultado de la division es "+resultado);
                    break;
                }
                case 4:
                {
                    System.out.println("Numero 1:");
                    n1 = reader.nextDouble();
                    System.out.println("Numero 2:");
                    n2 = reader.nextDouble();
                    resultado=n1/n2;
                    System.out.println("El resultado de la multiplicacion es "+resultado);
                    break;
                }
                case 5:
                {
                    System.out.println("--Calculadora paralela--");
                    
                    System.out.println("Numero 1:");
                    n1 = reader.nextDouble();
                    System.out.println("Numero 2:");
                    n2 = reader.nextDouble();
                    
                    hiloSuma.start();
                    hiloResta.start();
                    hiloMulti.start();
                    hiloDiv.start();
                    
                    
                    
                    break;
                    
                }
                case 6:
                {
                    System.out.println("Vuelva pronto");
                    break;
                }
                default:
                {
                    System.out.println("Seleccionaste una opcion no valida");
                    break;
                }
            }      
            
            try {
                Thread.sleep(3*1000);
                } catch (Exception e) {
                    System.out.println(e);
                }
            
            
            System.out.println("¿Desea realizar otra operacion?");
            System.out.println("1. Si");
            System.out.println("2. No");
            System.out.println("Opcion:");
            
            opc2 = reader.nextInt();
            
            if (opc2==1 || opc2==2) 
            {
                
                if (opc2==2) 
                {
                    opc=6;
                    System.out.println("Vuelva pronto");
                }
                else
                {
                    n1=0;
                    n2=0;

                    System.out.println("Escriba el numero de la operacion que desea realizar:");

                    opc = reader.nextInt();
                }
            }
            else
            {
                System.out.println("Opcion no valida");
            }
            
            
        }//fin while opc!=6          
    }
    
}
