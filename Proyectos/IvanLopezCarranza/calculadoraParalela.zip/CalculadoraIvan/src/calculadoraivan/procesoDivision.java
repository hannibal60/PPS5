/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package calculadoraivan;

import static calculadoraivan.calculadoraParalela.n1;
import static calculadoraivan.calculadoraParalela.n2;
import static calculadoraivan.calculadoraParalela.resultadoDivision;
import static calculadoraivan.procesoResta.redondearDecimales;


/**
 *
 * @author Ivan
 */

public class procesoDivision extends Thread
{
    @Override
    public void run()
    {
        //Scanner reader = new Scanner(System.in);
        
        //System.out.println("ESTE METODO LLAMA A LA SUMA DE PARALELA");
        //System.out.println("Numero 1:");
        //n1 = reader.nextInt();
        //System.out.println("Numero 2:");
        //n2 = reader.nextInt();
        resultadoDivision=n1/n2;
        
        //System.out.println("El resultado de la division es "+resultadoDivision);
        System.out.println(n1+" / "+n2+" = "+redondearDecimales(resultadoDivision,3));
    }
}