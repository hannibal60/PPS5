/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfazCalculadora;

import static interfazCalculadora.interfazCalculadora.campoRDivision;
import static interfazCalculadora.interfazCalculadora.num1;
import static interfazCalculadora.interfazCalculadora.num2;

/**
 *
 * @author Ivan
 */
public class procesoDivision extends Thread 
{
    public static Double resultadoDiv;
    
    
    @Override
    public void run()
    {
        System.out.println("AQUI MOSTRARE LA DIVISION PARALELA");
        
        Double resultado;
        
        resultado=Double.parseDouble(num1) / Double.parseDouble(num2);

        resultadoDiv=redondearDecimales(resultado,2);
        
        campoRDivision.setText(resultadoDiv.toString());
        
    }
    
    public static double redondearDecimales(double valorInicial, int numeroDecimales) {
        double parteEntera, resultado;
        resultado = valorInicial;
        parteEntera = Math.floor(resultado);
        resultado=(resultado-parteEntera)*Math.pow(10, numeroDecimales);
        resultado=Math.round(resultado);
        resultado=(resultado/Math.pow(10, numeroDecimales))+parteEntera;
        return resultado;
    }
    
}
