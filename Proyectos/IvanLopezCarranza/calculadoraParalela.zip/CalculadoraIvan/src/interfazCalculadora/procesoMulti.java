/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfazCalculadora;

import static calculadoraivan.procesoResta.redondearDecimales;
import static interfazCalculadora.interfazCalculadora.campoRMulti;
import static interfazCalculadora.interfazCalculadora.num1;
import static interfazCalculadora.interfazCalculadora.num2;

/**
 *
 * @author Ivan
 */
public class procesoMulti extends Thread

{
    public static Double resultadoMulti;
    
    
    @Override
    public void run()
    {
        System.out.println("AQUI MOSTRARE LA MULTIP PARALELA");
        
        /*resultadoMulti=Double.parseDouble(num1) * Double.parseDouble(num2);
        
        campoRMulti.setText(resultadoMulti.toString());*/
        //////////////////////////
        
        Double resultado;
        
        resultado=Double.parseDouble(num1) * Double.parseDouble(num2);

        resultadoMulti=redondearDecimales(resultado,2);
        
        campoRMulti.setText(resultadoMulti.toString());
        
    }
}
