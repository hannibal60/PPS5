/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfazCalculadora;

import static calculadoraivan.procesoResta.redondearDecimales;
import static interfazCalculadora.interfazCalculadora.campoRResta;
import static interfazCalculadora.interfazCalculadora.num1;
import static interfazCalculadora.interfazCalculadora.num2;

/**
 *
 * @author Ivan
 */
public class procesoResta extends Thread
{
     public static Double resultadoResta;
    
    
    @Override
    public void run()
    {
        System.out.println("AQUI MOSTRARE LA RESTA PARALELA");
        
        /*resultadoResta=Double.parseDouble(num1) - Double.parseDouble(num2);
        
        campoRResta.setText(resultadoResta.toString());*/
        
        ///////////////////////////////////////////
        
        Double resultado;
        
        resultado=Double.parseDouble(num1) - Double.parseDouble(num2);

        resultadoResta=redondearDecimales(resultado,2);
        
        campoRResta.setText(resultadoResta.toString());
        
        
    }
    
}
