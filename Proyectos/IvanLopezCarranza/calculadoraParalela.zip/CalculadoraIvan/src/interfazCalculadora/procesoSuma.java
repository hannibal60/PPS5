/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package interfazCalculadora;


import static calculadoraivan.procesoResta.redondearDecimales;
import static interfazCalculadora.interfazCalculadora.campoRSuma;
import static interfazCalculadora.interfazCalculadora.num1;
import static interfazCalculadora.interfazCalculadora.num2;

/**
 *
 * @author Ivan
 */
public class procesoSuma extends Thread
{   
    public static Double resultadoSuma;
    
    
    @Override
    public void run()
    {
        System.out.println("AQUI MOSTRARE LA SUMA PARALELA");
        
        /*resultadoSuma=Double.parseDouble(num1) + Double.parseDouble(num2);
        
        campoRSuma.setText(resultadoSuma.toString());*/
        
        ///////////////////////////////////////////
        
        Double resultado;
        
        resultado=Double.parseDouble(num1) + Double.parseDouble(num2);

        resultadoSuma=redondearDecimales(resultado,2);
        
        campoRSuma.setText(resultadoSuma.toString());
        
        
        //System.out.println(resultado);
        
    }
}
