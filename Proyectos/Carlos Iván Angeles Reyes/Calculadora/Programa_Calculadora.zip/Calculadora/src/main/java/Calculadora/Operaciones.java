
package Calculadora;

/**
 *
 * @author ivan_
 */
public class Operaciones 
{
    private double x;
    private double y;

    public Operaciones(double x, double y) {
        this.x = x;
        this.y = y;
    }

    public double getX() {
        return x;
    }

    public void setX(double x) {
        this.x = x;
    }

    public double getY() {
        return y;
    }

    public void setY(double y) {
        this.y = y;
    }
    
    public double operSuma(double x, double y)
    {
        return x+y;
    }
    
    public double operResta(double x, double y)
    {
        return x-y;
    }
    
    public double operMult(double x, double y)
    {
        return x*y;
    }
    
    public double operDiv(double x, double y)
    {
     
            return x/y;
        
        
    }
    
}
